import React from 'react';
import RegionSelect from './RegionSelect';

function App() {
  return (
    <div className="app">
      <RegionSelect />
    </div>
  );
}

export default App;
