import 'css/app.scss';
import $ from 'jquery';

$(() => {
 console.log('hi'); 
})
