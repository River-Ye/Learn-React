# optimization

- JS 最佳化，將 node_modules 裡的拆到 vendors.js 裡
- webpack 新增 alias 別名

```
npm install mini-css-extract-plugin
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
