# webpack_es6_import_export

# 安裝套件包
``` bash
npm install 套件包名稱
npm install 套件包名稱 -D (會被寫到 package.json 裡的 devDependencies)
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
