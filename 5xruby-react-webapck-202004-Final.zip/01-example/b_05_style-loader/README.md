# loader

- 裝這個 https://marketplace.visualstudio.com/items?itemName=christian-kohler.path-intellisense
- 可以有圖片路徑的提示

webpack 各種 loader

```
npm install css-loader file-loader
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
