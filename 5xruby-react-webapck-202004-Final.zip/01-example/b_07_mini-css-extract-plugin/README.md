# mini-css-extract-plugin

- 將 css 存成實體檔案
- sass-loader prependdata
- post-loader autoprefixer
- pug file live reload


```
npm install mini-css-extract-plugin
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
