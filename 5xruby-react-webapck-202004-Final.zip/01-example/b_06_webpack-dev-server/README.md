# webpack-dev-server

webpack 本機開發用

```
npm install webpack-dev-server
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
