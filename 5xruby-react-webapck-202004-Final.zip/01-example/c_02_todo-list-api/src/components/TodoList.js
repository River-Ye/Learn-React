import React from 'react';
import classnames from 'classnames';
import axios from 'axios';

import TodoForm from './TodoForm';
import TodoItem from './TodoItem';

export type TodoType ={
  id: string;
  text: string;
  done: boolean;
}

interface Props {
  url:string;
}
interface State {
  list: TodoType[];
  isLoading: boolean;
}

export default class TodoList extends React.Component<Props, State> {
  state = {
    list: [],
    isLoading: false,
  };

  // TODO: 3 start
  componentDidMount() {
    console.log('fetch list JSON Data');
    this.setState({ isLoading: true });

    /*
    axios.get('https://k9wvmn0z75.sse.codesandbox.io/api/list/403')
      .then(() => { })
      .catch((error) => {
        // console.log(error);
      });
    */

    axios.get(this.props.url).then((response) => {
      this.setState({
        list: response.data,
        isLoading: false,
      });
    });
  }
  // TODO: 3 end

  // TODO: 4 start
  addItem = (text:string) => {
    this.setState({ isLoading: true });
    axios({
      method: 'POST',
      url: this.props.url,
      data: {
        text,
      },
    })
      .then((response) => {
        const { data } = response;
        this.setState((state) => ({
          list: state.list.concat(data),
          isLoading: false,
        }));
      });
  }
  // TODO: 4 end

  // TODO: 5 start
  toggleItem = (id:string) => {
    this.setState({ isLoading: true });
    axios({
      method: 'PUT',
      url: this.props.url,
      data: { id },
    })
      .then((response) => {
        const { data } = response;
        this.setState({
          list: data,
          isLoading: false,
        });
      });
  }
  // TODO: 5 end

  render() {
    const { isLoading, list } = this.state;
    const clazz = classnames('todo-list', {
      'is-loading': isLoading,
    });
    return (
      <div className={clazz}>
        <TodoForm addItem={this.addItem} />
        <ul className="todo-items">
          {
            list.map((item) => (
              <TodoItem
                key={item.id}
                id={item.id}
                done={item.done}
                toggleItem={this.toggleItem}
              >
                {item.text}
              </TodoItem>
            ))
          }
        </ul>
      </div>
    );
  }
}
