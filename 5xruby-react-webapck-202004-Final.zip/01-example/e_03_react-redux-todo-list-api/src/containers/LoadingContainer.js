import { connect } from 'react-redux';
import { type State } from '@/types';
import Loading from '../components/Loading';

function mapStateToProps(state:State) {
  return {
    show: state.common.loading,
  };
}
function mapDispatchToProps() {
  return { };
}

export default connect(mapStateToProps, mapDispatchToProps)(Loading);
