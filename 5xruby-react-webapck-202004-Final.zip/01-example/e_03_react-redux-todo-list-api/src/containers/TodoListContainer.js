import { connect } from 'react-redux';
import { type State } from '@/types';
import TodoList from '../components/TodoList';
import { toggleTodo } from '../actions';


const mapStateToProps = (state:State) => ({
  todos: state.todos,
});

const mapDispatchToProps = (dispatch) => ({
  toggleItem(id:string) {
    dispatch(toggleTodo(id));
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
