import { connect } from 'react-redux';
import { type State } from '@/types';
import { actionClearTodo } from '../actions';
import TodoClear from '../components/TodoClear';

function mapStateToProps(state:State) {
  return {
    count: state.todos.length,
  };
}
function mapDispatchToProps(dispatch) {
  return {
    onClear() {
      dispatch(actionClearTodo());
    },
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(TodoClear);
