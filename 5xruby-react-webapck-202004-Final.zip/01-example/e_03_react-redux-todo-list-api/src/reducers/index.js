import { combineReducers } from 'redux';
import common from './common';
import todos from './todos';


const reducers = combineReducers({
  common,
  todos,
});

export default reducers;
