import { type TodoType } from '@/types';
import { getTodoList } from '../api/fetch';

export function actionAddTodo(text:string) {
  return {
    type: 'ADD_TODO',
    text,
  };
}

export function actionClearTodo() {
  return {
    type: 'CLEAR_TODO',
  };
}


export function changeLoading(loading:boolean) {
  return {
    type: 'CHANGE_LOADING',
    value: loading,
  };
}


export function toggleTodo(id:string) {
  return {
    type: 'TOGGLE_TODO',
    id,
  };
}

function receiveProducts(todos:TodoType[]) {
  return {
    type: 'RECEIVE_TODOLIST',
    todos,
  };
}


export function fetchTodoList() {
  console.log('fetchTodoList');
  return function (dispatch, getState) {
    console.log(getState());
    dispatch(changeLoading(true));
    getTodoList().then((todos:TodoType[]) => {
      dispatch(receiveProducts(todos));
      dispatch(changeLoading(false));
    });
  };
}
