import React from 'react';

interface Props {
  addItem: (text:string)=>void;
}

function TodoForm(props:Props) {
  const inputRef: React.MutableRefObject<HTMLInputElement> = React.useRef();
  const onSubmit = React.useCallback((e) => {
    e.preventDefault();
    const text = inputRef.current.value;
    if (text === '') {
      return;
    }
    inputRef.current.value = '';
    props.addItem(text);
  }, []);
  return (
    <section data-name="TodoForm">
      <form className="todo-form" onSubmit={onSubmit}>
        <input type="text" ref={inputRef} />
      </form>
    </section>
  );
}
export default React.memo(TodoForm);
