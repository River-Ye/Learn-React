/**
 * Mocking client-server processing
 */
import { type TodoType } from '@/types';


const MOCK_TODO_LIST:TodoType[] = [
  {
    id: 'fakeid',
    text: '學會 React',
    done: true,
  },
  {
    id: 'fakeid2',
    text: '年薪百萬',
    done: false,
  },
];


export function getTodoList():Promise<TodoType[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(MOCK_TODO_LIST);
    }, 1500);
  });
}
