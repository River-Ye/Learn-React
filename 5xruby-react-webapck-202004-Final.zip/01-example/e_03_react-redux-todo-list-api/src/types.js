export type TodoType = {
  id: string;
  text: string;
  done: boolean;
}

export type State = {
  common:{
    loading: boolean;
  };
  todos: TodoType[],
};
