import React from 'react';

export default function Home() {
  return (
    <div className="home-root">
      <div className="jumbotron">
        <h3 className="display-3">Hello React</h3>
      </div>
    </div>
  );
}
