export type Store = {
  user: {
    name: string,
    permission: number
  }
}
