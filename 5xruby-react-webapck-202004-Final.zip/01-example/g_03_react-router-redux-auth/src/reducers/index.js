import { combineReducers } from 'redux';
import user from './user';

const combine = combineReducers({
  user,
});

export default combine;
