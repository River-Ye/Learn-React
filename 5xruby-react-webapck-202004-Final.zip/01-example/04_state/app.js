class Counter extends React.Component {
  constructor(props){
    super(props);
    // TODO: 1
    this.state = { count: 0 };
  }
  render () {
    // TODO: 2 start
    return (
      <div className="counter">
        <h1>Counter</h1>
        <div className="count">{this.state.count}</div>
      </div>
    );
    // TODO: 2 end
  }
}

ReactDOM.render(
  // TODO: 3
  <Counter/>,
  document.getElementById('app')
);