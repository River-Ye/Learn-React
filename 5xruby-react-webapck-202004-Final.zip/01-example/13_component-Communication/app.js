ReactDOM.render(
  <ParentComponent />,
  document.getElementById('app')
);
