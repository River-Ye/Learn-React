import { combineReducers } from 'redux';
import count from './count';

const reducers = combineReducers({
  count,
});

export default reducers;
