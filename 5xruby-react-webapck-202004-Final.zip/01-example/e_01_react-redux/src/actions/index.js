export function actionIncrease() {
  return {
    type: 'INCREASE',
  };
}

export function actionDecrease() {
  return {
    type: 'DECREASE',
  };
}
