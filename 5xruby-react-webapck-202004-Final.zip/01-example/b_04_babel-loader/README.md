# babel preset-env

依 .babelrc 設定，來決定 compiler 模式

```
npm install @babel/core @babel/preset-env
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
