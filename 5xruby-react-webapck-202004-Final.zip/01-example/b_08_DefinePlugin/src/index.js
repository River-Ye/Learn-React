import 'css/app.scss';
console.log('process.env.NODE_ENV', process.env.NODE_ENV);
console.log('boolean', process.env.DEF_BOO);
console.log('number', process.env.DEF_NUM);
console.log('object', process.env.DEF_OBJ);
console.log('string', process.env.DEF_STR);
console.log('WEB_URL', process.env.WEB_URL);