# DefinePlugin
- 定義變數給 JS 使用 process.env.你的變數名稱

```
npm install mini-css-extract-plugin
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
