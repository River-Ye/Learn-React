## 改用 cross-env 來設定 NODE_ENV 變數

``` bash
npm install cross-env
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
