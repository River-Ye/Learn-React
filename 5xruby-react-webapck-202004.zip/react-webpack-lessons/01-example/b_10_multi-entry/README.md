# Multi entry

- Webpack 多程式進入點
- 使用 chokidar 讓 html live reload

```
npm install mini-css-extract-plugin
```

## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
