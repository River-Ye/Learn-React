export const add = (a,b) =>{
return a +b
}
