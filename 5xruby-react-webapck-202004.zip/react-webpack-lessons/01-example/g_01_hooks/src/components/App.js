/* eslint no-unused-vars:0 */
import React, { useState, useEffect } from 'react';

import Hooks0 from './Hooks0';
import Hooks1 from './Hooks1';
import Hooks2 from './Hooks2';
import Hooks3 from './Hooks3';
import Hooks4 from './Hooks4';
import Hooks5 from './Hooks5';
import Hooks6 from './Hooks6';
import Hooks7 from './Hooks7';
import Hooks8 from './Hooks8';
import Hooks9 from './Hooks9';
import HooksRx from './HooksRx';

export default function App() {
  return (
    <div className="app">
      <div className="container">
        <Hooks0 />
        <Hooks1 />
        <Hooks2 />
        <Hooks3 />
        <Hooks4 />
        <Hooks5 />
        <Hooks6 />
        <Hooks7 />
        <Hooks8 />
        <Hooks9 />
        {/* <HooksRx /> */}
      </div>
    </div>
  );
}
