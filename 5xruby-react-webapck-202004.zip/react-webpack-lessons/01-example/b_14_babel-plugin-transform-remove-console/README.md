# babel-plugin-transform-remove-console 

- production 發佈時，移掉所有的 console.log
- `npm i babel-plugin-transform-remove-console`
- .babelrc 新增設定


## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
