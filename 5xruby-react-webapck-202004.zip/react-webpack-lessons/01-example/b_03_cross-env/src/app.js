﻿

var NODE_ENV = process.env.NODE_ENV;
console.log(NODE_ENV);
console.log(9527);

document.getElementById('info').textContent = NODE_ENV;