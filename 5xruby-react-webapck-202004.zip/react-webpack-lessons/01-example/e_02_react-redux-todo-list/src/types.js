export type TodoType = {
  id: string;
  text: string;
  done: boolean;
}
