// 因為在 webpack.config 裡有設定 resolve modules ，所以會自動從 src 資料找
// 就不需要寫相對路徑(但不推這樣的寫法)
import 'css/app.scss';

console.log('-------- app.js ---------');