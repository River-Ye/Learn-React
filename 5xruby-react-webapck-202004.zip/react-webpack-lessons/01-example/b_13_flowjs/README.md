# flowjs 

- babel/preset-flow https://babeljs.io/docs/en/babel-preset-flow
- eslint flowjs https://github.com/gajus/eslint-plugin-flowtype


## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
