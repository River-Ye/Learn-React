# weinre remoting debug 
- 遠端裝置 Debugging
- npm run weinre
- npm run start:weinre


## install package Command line
``` bash
npm install
```

## Development Command line
``` bash
# build for developemnt
npm run start
```

## Production Command line
``` bash
# build for production with minification
npm run build
```
