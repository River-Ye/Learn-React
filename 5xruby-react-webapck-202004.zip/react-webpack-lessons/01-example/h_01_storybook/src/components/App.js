import React from 'react';

import Checkbox from '@/components/Checkbox';


export default function App() {
  return (
    <div className="app container">
      <Checkbox />
    </div>
  );
}
